package com.resourcetrackingmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.resourcetrackingmanagement.model.Requests;

public interface RequestsRepository extends JpaRepository<Requests, Long> {

}
