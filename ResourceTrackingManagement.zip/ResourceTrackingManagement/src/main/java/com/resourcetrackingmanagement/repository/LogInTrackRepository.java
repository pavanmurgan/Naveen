package com.resourcetrackingmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.resourcetrackingmanagement.model.LogInTrack;

public interface LogInTrackRepository extends JpaRepository<LogInTrack, Long> {

}
