package com.resourcetrackingmanagement.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T_LOGIN_DETAILS")
public class LogInTrack {

	@Id
	@Column(name = "userId")
	private int userId;

	@Column(name = "loginTime")
	private Date loginTime;

	@Column(name = "logoutTime")
	private Date logoutTime;

	@Column(name = "active")
	private int active;

	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}

	/**
	 * @return the loginTime
	 */
	public Date getLoginTime() {
		return loginTime;
	}

	/**
	 * @param loginTime the loginTime to set
	 */
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}

	/**
	 * @return the logoutTime
	 */
	public Date getLogoutTime() {
		return logoutTime;
	}

	/**
	 * @param logoutTime the logoutTime to set
	 */
	public void setLogoutTime(Date logoutTime) {
		this.logoutTime = logoutTime;
	}

	/**
	 * @return the active
	 */
	public int getActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(int active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "LogInTrack [userId=" + userId + ", loginTime=" + loginTime + ", logoutTime=" + logoutTime + ", active="
				+ active + "]";
	}

}
