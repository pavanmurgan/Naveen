package com.resourcetrackingmanagement;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.resourcetrackingmanagement.model.Groups;
import com.resourcetrackingmanagement.model.TaskList;
import com.resourcetrackingmanagement.model.Users;
import com.resourcetrackingmanagement.service.ResourceTrackingService;

@Controller
public class ResourceTrackingController {

	@Autowired
	ResourceTrackingService resourceTrackingService;
	
	@PostMapping(value = "/register")
	public void userRegistration(Users users) {
		resourceTrackingService.userRegistration(users);
	}
	
	@PostMapping(value = "/creategroup")
	public void createGroup(Groups groups) {
		resourceTrackingService.createGroup(groups);
	}
	
	@PostMapping(value = "/createtask")
	public void createTaskGroup(TaskList taskList) {
		taskList.setProgress("Started");
		resourceTrackingService.createTaskGroup(taskList);
	}
	
	
	@GetMapping(value = "/approveuser")
	public void approveUser(Users users, String email, String role) {
		List<Users> userList = new ArrayList<Users>();
		for(Users user : userList) {
			if(user.getEmail().equals(email)) {
				resourceTrackingService.approveUser(user, role);
			}
		}
	}
	
	
	
	
}
