package com.boulanger.DAO;

import java.util.List;

import com.boulanger.model.Admin;
import com.boulanger.model.Items;
import com.boulanger.model.Order;
import com.boulanger.model.Table1;
import com.boulanger.model.Users;

public interface UserDAOInterface {
	
	public void signupData(Users user) throws Exception;
	
	public Users loginData(String email);
	
	public void addItemData(Items item)  throws Exception;

	public List<Items> itemsData();
	
	public Items itemData(String itemId);
	
	public void orderDataSave(Order order);
	
	public List<Order> orderData(String email);
	
	public void reservationDataSave(Table1 table);
	
	public List<Table1> reservationData();
	
	public List<Order> orderData1();
	
	public Admin adminData();
	
	public void passwordChange(Users user);
	
	public boolean updateUserData(String email,String value,String option);
}
