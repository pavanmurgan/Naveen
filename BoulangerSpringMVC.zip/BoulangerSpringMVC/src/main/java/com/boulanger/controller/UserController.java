package com.boulanger.controller;


import java.util.List;
import java.util.Random;


import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boulanger.model.Items;
import com.boulanger.model.Order;
import com.boulanger.model.Table1;
import com.boulanger.model.Users;
import com.boulanger.service.UserServiceInterface;



@Controller
@Scope("session")
public class UserController {
	
	@Autowired
	private UserServiceInterface userService;
	
	final static Logger logger = Logger.getLogger(UserController.class);
	

	@RequestMapping("/")
	public String homePage(HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.setAttribute("email", null);
		session.setAttribute("adminemail", null);
		session.setAttribute("mes", "");
		session.setAttribute("mes1", "");
		session.setAttribute("mes2", "");
		
		return "index";
	}
	
	@RequestMapping("/successPage")
	public String successPage(HttpServletRequest request) {
		HttpSession session=request.getSession();
		
		if(session.getAttribute("email") != null) {
				return "successPage";
		} else {
			return "redirect:errorPage";
		}
	}
	
	@RequestMapping("/forgotPassword")
	public String forgotPassword(Model model,HttpServletRequest request) {
		HttpSession session=request.getSession();
		model.addAttribute("mes1", session.getAttribute("mes1"));
		return "ForgotPassword";
		
	}
	
	
	@RequestMapping("/forgotPasswordSubmit")
	public String forgotPasswordSubmit(Model model,HttpServletRequest request) {
		
		if(request.getParameter("email") != null) {
		String page = "redirect:signin";
		String email = request.getParameter("email");
		logger.info(request.getParameter("email"));
		HttpSession session=request.getSession();
		
		if(userService.forgotPasswordService(email)) {
			
			Random rand = new Random();
			int low = 1000;
			int high = 9999;
			int otp = rand.nextInt(high-low) + low;
			
			
			logger.info("OPT generated");
			model.addAttribute("otp", otp);
			model.addAttribute("email1", email);
			logger.info(otp);
			
			page = "ResetPassword";
			
		} else {
			
			session.setAttribute("mes", "User Not Registred");
		}
		
		return page;
		} else {
			return "redirect:errorPage";
		}
	}
	
	@RequestMapping("resetPasswordSubmit")
	public String resetPasswordSubmit(HttpServletRequest request) {
		String page = "redirect:forgotPassword";
		HttpSession session=request.getSession();
		
		int userOtp = Integer.parseInt(request.getParameter("OTP").toString());
		String email = request.getParameter("email1").toString();
		int otp = Integer.parseInt(request.getParameter("otp1").toString());
		
		if(userOtp == otp) {
		
			Users u = new Users();
			u.setUserPassword(request.getParameter("ResetPassword"));
			u.setUserEmail(email);
			userService.passwordChangeService(u);
			session.setAttribute("mes", "Password Changed Successfully");
			page="redirect:signin";
		} else {
			session.setAttribute("mes1", "Incorrect OTP");
		}
		
		return page;
	}
	
	
	
	@RequestMapping("/index")
	public String indexPage(HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.setAttribute("mes", "");
		return "index";
	}

	@RequestMapping("/reservation")
	public String reservation() {
		return "Reservation";
	}
	
	
	@RequestMapping("/errorPage")
	public String errorPage() {
		return "errorPage";
	}
	
	@RequestMapping("/profile")
	public String profilePage(Model model,HttpServletRequest request) {
		
		HttpSession session=request.getSession();
		String email = session.getAttribute("email").toString();
		
		Users u = new Users();
		u.setUserEmail(email);
		Users user = userService.userDataService(u);
		List<Order> orders = userService.orderDataService(email);
			if(user.getUserAddress().equals("b")) {
				user.setUserAddress("");
			}
			if(user.getUserName().equals("a")) {
				user.setUserName("");
			}
		model.addAttribute("user",user);
		model.addAttribute("orders", orders);
		
		session.setAttribute("address", user.getUserAddress());
		System.out.println(session.getAttribute("address"));
		return "profile";
	}
	
	
	@RequestMapping("/signup")
	public String loginPage(@ModelAttribute("reg") Users user,HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.setAttribute("mes", "");
		return "Registration";
	}
	
	@RequestMapping("/signupSubmit")
	public String signup(@Valid @ModelAttribute("reg") Users user,Errors errors,HttpServletRequest request) {
		HttpSession session=request.getSession();
		String page ="redirect:signup";
		
		if(errors.hasErrors()) {
			System.out.println(errors.getErrorCount());
		} else {
			
			if(user.getUserEmail().equals("admin@gmail.com")) {			
				session.setAttribute("mes", "This email is not Permited");
				page="redirect:signin";
			} else {
				user.setUserAddress("b");
				user.setUserName("a");
				try {
				userService.signupService(user);
				session.setAttribute("mes", "Registred Successfully");
				} catch(Exception e) {
					session.setAttribute("mes", "User already Registred");
				}
				page="redirect:signin";
			}
		}
		
		return page;
		
	}
	
	@RequestMapping("/cart")
	public String cartPage(Model model,HttpServletRequest request) {
		HttpSession session=request.getSession();
		if(session.getAttribute("email") != null) {
		
		logger.info(request.getParameter("val"));
		
		session.setAttribute("val", request.getParameter("val").toString());
		
		Items i = userService.itemDataService(request.getParameter("val").toString());
		model.addAttribute("i",i);
		
		return "cart";
		} else {
			return "redirect:signin";
		}
	}
	
	@RequestMapping("/signin")
	public String signinPage(Model model,@ModelAttribute("sig") Users user,HttpServletRequest request) {
		HttpSession session=request.getSession();
		model.addAttribute("mes", session.getAttribute("mes").toString());
		return "login";
	}
	
	
	
	@RequestMapping("/loginSubmit")
	public String loginSubmit(@Valid @ModelAttribute("sig") Users user,Errors errors,HttpServletRequest request) {
		
		String page ="redirect:signin";
		
		logger.info(request.getParameter("User"));
		String option = request.getParameter("User");
		HttpSession session=request.getSession();
		
		
		
		
		if(errors.hasErrors()) {
			logger.info(errors.getErrorCount());
		} else {
			
			if(option.equals("User")) {
			
				if(userService.siginService(user)) {
					
					session.setAttribute("email", user.getUserEmail());
					page="redirect:profile";
				} else {
					session.setAttribute("mes", "Invalid Credentials");
					page="redirect:signin";
				}
				
			} else {
				
				if(userService.adminsigninService(user)) {
					session.setAttribute("adminemail", user.getUserEmail());
					page="redirect:admin";
				} else {
					session.setAttribute("mes", "Invalid Credentials");
					page="redirect:signin";
				}
				
				
			}
			
		}
		
		
		return page;
	}
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session=request.getSession();
		if(session.getAttribute("email") != null) {
        session.invalidate();
		return "redirect:index";
		} else {
			return "redirect:signin";
		}
	}
	
	
	@RequestMapping("/checkout")
	public String checkoutPage(Model model,HttpServletRequest request) {
		
		
		HttpSession session=request.getSession();
		if(session.getAttribute("email") != null) {
	
		logger.info(request.getParameter("quantity"));;
        session.setAttribute("quantity",request.getParameter("quantity").toString());
        
        Items i = userService.itemDataService(session.getAttribute("val").toString());
        
        Double i123 = i.getItemCost();
		int q = Integer.parseInt(session.getAttribute("quantity").toString());
		
		Double sum = i123 * q;
		
		session.setAttribute("sum",sum);
		model.addAttribute("i1", i);
        
        return "checkout";
		} else {
			return "redirect:signin";
		}
	}
	
	@RequestMapping("/menu")
	public String menuPage(Model model,HttpServletRequest request) {
		
		HttpSession session=request.getSession();
		List<Items> l = userService.itemsDataService();
		
		model.addAttribute("items",l);
		model.addAttribute("mes2",session.getAttribute("mes2"));
		
		return "menu";
	}
	
	@RequestMapping("/contact")
	public String contactPage() {
		return "contact";
	}
	
	
	@RequestMapping("/orderSubmit")
	public String orderSubmit(HttpServletRequest request) {
		
		
		HttpSession session=request.getSession();
		System.out.println(session.getAttribute("address"));
		if(session.getAttribute("address").toString() == "") {
			session.setAttribute("mes2", "Address given was not Valid");
			return "redirect:menu";
		} else {
			
			Random rand = new Random();
			
			Items i = userService.itemDataService(session.getAttribute("val").toString());
			
			Order o = new Order();
			o.setEmail(session.getAttribute("email").toString());
			o.setItemName(i.getItemName());
			o.setAddress(session.getAttribute("address").toString());
			o.setQuantity(session.getAttribute("quantity").toString());
			o.setAmount(session.getAttribute("sum").toString());
			o.setOrderNo(""+rand.nextInt(13487)+"");
			
			userService.orderDataSaveService(o);
			
			return "redirect:successPage";
		}
		
	}
	
	@RequestMapping("/reservationSubmit")
	public String reservationSubmit(HttpServletRequest request) {
		Table1 t = new Table1();
		t.setFirstName(request.getParameter("mfname"));
		t.setLastName(request.getParameter("mlname"));
		t.setEmail(request.getParameter("memail"));
		t.setNumberOfPeople(request.getParameter("mpeople"));
		t.setPhone(request.getParameter("mphone"));
		t.setDate1(request.getParameter("mdate"));
		t.setTime(request.getParameter("mtime"));
		t.setMsg(request.getParameter("mmessage"));
		userService.reservationDataSaveService(t);
		return "redirect:index";
	}
	
	@RequestMapping("/updateUserDataSubmit")
	public String updateUserDataSubmit(HttpServletRequest request) {
		
		System.out.println("UpdateCame");
		HttpSession session=request.getSession();
		String option = request.getParameter("value");
		String value ="";
		String email = session.getAttribute("email").toString();
		
		switch(option) {
		case "name":
			value = request.getParameter("userName");
			break;
		case "address":
			value = request.getParameter("userAddress");
			break;
		case "email":
			value = request.getParameter("userEmail");
			break;
		case "mobileNumber":
			value = request.getParameter("userMobileNumber");
			break;
		default:
			value = "a";
			break;
		}
		
		if(userService.updateUserDataService(email,value,option)) {
			return "redirect:profile";
		}
		
		return "redirect:profile";
	}
	
	
}
