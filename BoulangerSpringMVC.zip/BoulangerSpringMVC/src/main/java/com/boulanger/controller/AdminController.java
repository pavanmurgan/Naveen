package com.boulanger.controller;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boulanger.model.Admin;
import com.boulanger.model.Items;
import com.boulanger.model.Order;
import com.boulanger.model.Table1;
import com.boulanger.service.UserServiceInterface;


@Controller
@Scope("session")
public class AdminController {
	
	@Autowired
	private UserServiceInterface userService;
	
	final static Logger logger = Logger.getLogger(AdminController.class);
	
	@RequestMapping("/admin")
	public String adminPage(Model model,HttpServletRequest request) {
		
		HttpSession session=request.getSession();
		if(session.getAttribute("adminemail") != null) {
			
		List<Table1> t = userService.reservationDataService();
		model.addAttribute("tables", t);
		List<Items> l = userService.itemsDataService();
		List<Order> o = userService.orderDataService1();
		Admin a = userService.adminDataService();
		model.addAttribute("admin", a);
		model.addAttribute("items1",l);
		model.addAttribute("orders1", o);
		
		return "admin";
		} else {
			return "redirect:signin";
		} 
	}
	
	@RequestMapping("/addItemSubmit")
	public String addItemSubmit(HttpServletRequest request) {
		
		HttpSession session=request.getSession();
		
		if(session.getAttribute("adminemail") != null) {
			
		
		String page ="redirect:successPage1";
		
			Random rand = new Random();
			
			int z = rand.nextInt(13487);
			BufferedImage image = null;
	        try {
	          
	            File file1 = new File(request.getParameter("itemImage"));
	           
	            logger.info(request.getParameter("itemImage"));
	            image = ImageIO.read(file1);
	            
	            ImageIO.write(image, "jpg",new File("C:\\Users\\pavanm\\Downloads\\BoulangerSpringMVC\\BoulangerSpringMVC\\src\\main\\webapp\\resources\\theme1\\images1\\"+z+".jpg"));
	            
	        } catch (IOException e) {
	        	e.printStackTrace();
	        }
	     
	        
	        Items i = new Items();
	        
	        i.setItemName(request.getParameter("itemName"));
			i.setItemId(request.getParameter("itemId"));
			i.setItemDescription(request.getParameter("itemDescription"));
			i.setItemCost(Double.parseDouble(request.getParameter("itemCost")));
			i.setItemImageUrl(z+".jpg");
	        
			try {
				userService.addItemService(i);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				page="redirect:errorPage2";
				
			}
			return page;
			
		} else {
			return "redirect:signin";
		}
		
		
		
		
	}
	
	@RequestMapping("/errorPage2")
	public String errorPage2() {
		return "errorPage2";
	}
	
	@RequestMapping("/successPage1")
	public String successPage1(HttpServletRequest request) {
		HttpSession session=request.getSession();
		if(session.getAttribute("adminemail") != null) {
		return "successPage1";
		} else {
			return "redirect:signin";
		}
	}
	
	@RequestMapping("/adminLogout")
	public String adminLogout(HttpServletRequest request) {
		HttpSession session=request.getSession();
		if(session.getAttribute("adminemail") != null) {
		return "redirect:index";
		} else {
			return "redirect:signin";
		}
	}
	
}