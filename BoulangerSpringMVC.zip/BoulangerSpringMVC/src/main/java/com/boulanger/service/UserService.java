package com.boulanger.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boulanger.DAO.UserDAOInterface;
import com.boulanger.model.Admin;
import com.boulanger.model.Items;
import com.boulanger.model.Order;
import com.boulanger.model.Table1;
import com.boulanger.model.Users;

@Service
public class UserService implements UserServiceInterface{
	
	@Autowired
	private UserDAOInterface userDAO;

	@Override
	public void signupService(Users user) throws Exception {
		
		userDAO.signupData(user);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean siginService(Users user) {
		// TODO Auto-generated method stub
		
		Users user1 = userDAO.loginData(user.getUserEmail());
		
		if(user!=null&&user1!=null)
		{
			System.out.println(user1.getUserPassword());
			if((user.getUserEmail().equals(user1.getUserEmail()))&&(user.getUserPassword().equals(user1.getUserPassword())))
			{
				return true;
			}
		
		}
		
		return false;
		
	}
	
	@Override
	public boolean forgotPasswordService(String email) {
		
		Users user1 = userDAO.loginData(email);
		
		if(user1 != null) {
			return true;
		}
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean adminsigninService(Users user) {
		
		Admin admin1 = userDAO.adminData();
		
		if(user!=null&&admin1!=null) {
			if((user.getUserEmail().equals(admin1.getEmail()))&&(user.getUserPassword().equals(admin1.getPassword())))
			{
				return true;
			}
		}
		
		
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Users userDataService(Users user) {
		// TODO Auto-generated method stub
		Users user1 = userDAO.loginData(user.getUserEmail());
		return user1;
	}

	@Override
	public void addItemService(Items item)  throws Exception {
		
		userDAO.addItemData(item);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Items> itemsDataService() {
		// TODO Auto-generated method stub
		return userDAO.itemsData();
	}

	@Override
	public Items itemDataService(String itemId) {
		// TODO Auto-generated method stub
		
		
		
		return userDAO.itemData(itemId);
	}

	@Override
	public void orderDataSaveService(Order order) {
		
		userDAO.orderDataSave(order);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Order> orderDataService(String email) {
		
		// TODO Auto-generated method stub
		return userDAO.orderData(email);
	}

	@Override
	public void reservationDataSaveService(Table1 table) {
		
		userDAO.reservationDataSave(table);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Table1> reservationDataService() {
		
		// TODO Auto-generated method stub
		return userDAO.reservationData();
	}

	@Override
	public List<Order> orderDataService1() {
		
		
		// TODO Auto-generated method stub
		return userDAO.orderData1();
	}

	@Override
	public Admin adminDataService() {
		// TODO Auto-generated method stub
		return userDAO.adminData();
	}

	@Override
	public void passwordChangeService(Users user) {
		
		userDAO.passwordChange(user);
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean updateUserDataService(String email, String value, String option) {
		userDAO.updateUserData(email, value, option);
		return false;
	}

	

	

}
