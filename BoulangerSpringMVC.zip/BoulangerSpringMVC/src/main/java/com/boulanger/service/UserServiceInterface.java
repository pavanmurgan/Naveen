package com.boulanger.service;

import java.util.List;

import com.boulanger.model.Admin;
import com.boulanger.model.Items;
import com.boulanger.model.Order;
import com.boulanger.model.Table1;
import com.boulanger.model.Users;

public interface UserServiceInterface {
	
	public void signupService(Users user) throws Exception;
	public boolean siginService(Users user);
	public Users userDataService(Users user);
	public void addItemService(Items item)  throws Exception;
	public List<Items> itemsDataService();
	public Items itemDataService(String itemId);
	public void orderDataSaveService(Order order);
	public List<Order> orderDataService(String email);
	public void reservationDataSaveService(Table1 table);
	public List<Table1> reservationDataService();
	public List<Order> orderDataService1();
	public Admin adminDataService();
	public boolean adminsigninService(Users user);
	public boolean forgotPasswordService(String email);
	public void passwordChangeService(Users user);
	public boolean updateUserDataService(String email,String value,String option);

}
