package com.boulanger.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="itemdetails")
public class Items implements java.io.Serializable {
	
	@Id
	private String itemName;
	private String itemId;
	private String itemDescription;
	private Double itemCost;
	private String itemImageUrl;
	
	
	
	public Items() {
		super();
	}



	public Items(String itemName, String itemId, String itemDescription, Double itemCost, String itemImageUrl) {
		super();
		this.itemName = itemName;
		this.itemId = itemId;
		this.itemDescription = itemDescription;
		this.itemCost = itemCost;
		this.itemImageUrl = itemImageUrl;
	}



	public String getItemName() {
		return itemName;
	}



	public void setItemName(String itemName) {
		this.itemName = itemName;
	}



	public String getItemId() {
		return itemId;
	}



	public void setItemId(String itemId) {
		this.itemId = itemId;
	}



	public String getItemDescription() {
		return itemDescription;
	}



	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}



	public Double getItemCost() {
		return itemCost;
	}



	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}



	public String getItemImageUrl() {
		return itemImageUrl;
	}



	public void setItemImageUrl(String itemImageUrl) {
		this.itemImageUrl = itemImageUrl;
	}
	

}
